package proyectoandres;

import Vista.*;
import Modelo.UML.*;
import Modelo.BD.*;
import Excepcion.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author andrés
 */
public class Main {

    private static VistaCentro vc;
    private static VistaTrabajador vt;
    private static Centro c;
    private static Trabajador t;
    private static ArrayList <String> listaCentros;
    private static ArrayList <String> listaTrabajadores;
    private static Connection conexion;
    
    
    public static void main(String[] args){
        vc = new VistaCentro();
        vc.setVisible(true);
        rellenaCentros();
    }   
    
    public static void rellenaCentros(){
        try{
            listaCentros = CentroBD.getCentros(conexion, c.getIdCentro(), c); 
            ArrayList<String> aCentros = new ArrayList();
            vc.setCentros(aCentros.toArray());
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problemas al realizar query: "+e);
        }
        if(!GenericoBD.cerrarBD(conexion)){
            JOptionPane.showMessageDialog(null,"Problemas al cerrar");
        }
    }
       
    public static void selectCentro(String idCentro){
        vc.dispose();
        try{
            ArrayList<String> listaPorIdCen = TrabajadorBD.getTrabajadoresIdCentro(conexion,c.getIdCentro());
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problemas al realizar query: "+e);
        }
        if(!GenericoBD.cerrarBD(conexion)){
            JOptionPane.showMessageDialog(null,"Problemas al cerrar");
        }
        vt = new VistaTrabajador();
    }
    
    public static String getTrabajadores(String dni) throws Exception
    {
        ArrayList<String> lista = TrabajadorBD.getTrabajador(t, dni); 
        String datos="";
        for(int x = 0; x < lista.size(); x++)
        datos += lista.get(x).toString();
        return datos;
    }
    
    public static boolean buscarIdCentro(String idCentro) throws Exception
    {
        CentroBD.getCentros(conexion, idCentro, c);
        return c != null;
    }
    
    public static void bajaTrabajador() throws Exception{
        TrabajadorBD.eliminar(conexion, t);
    }
    
    public static void altaTrabajador(String dni, String nom, String primap, String segunap, String portal, String piso, String calle, String mano,  String tfmov, String tfper, String sal, Date fech, String tipo) throws Exception{
        t = new Trabajador ();
        t.setDNI(dni); t.setNombre(nom); t.setApe1(primap); t.setApe2(segunap); t.setPortalTrab(portal); 
        t.setPisoTrab(piso); t.setCalleTrab(calle);   t.setManoTrab(mano); t.setTlfPersonal(tfper); t.setMovilEmp(tfmov); 
        t.setSalario(sal); t.setFechaNac(fech); 
 
        TrabajadorBD.alta(conexion, t, tipo); 
    }
    
    public static void modificarTrab(String dni, String nom, String primap, String segunap, String portal, String piso, String calle, String mano,  String tfmov, String tfper, String sal, Date fech, String tipo) throws Exception {
        t.setDNI(dni); t.setNombre(nom); t.setApe1(primap); t.setApe2(segunap); t.setPortalTrab(portal); 
        t.setPisoTrab(piso); t.setCalleTrab(calle);   t.setManoTrab(mano); t.setTlfPersonal(tfper); t.setMovilEmp(tfmov); 
        t.setSalario(sal); t.setFechaNac(fech);
        
        TrabajadorBD.modificacion(conexion, t, tipo);
    }
    
    public static String getCentro(int index){
        CentroBD.getCentros(conexion, listaCentros.get(index), c); 
        return c.getNombreCen();
    }
     
    public static String getIdCentro(){
        return c.getIdCentro();
    }

    public static String getNombre(){
        return t.getNombre();
    }

    public static String getApe1(){
        return t.getApe1();
    }

    public static String getApe2(){
         return t.getApe2();
    }

    public static String getCalle(){
         return t.getCalleTrab();
    }

    public static String getPortal(){
         return t.getPortalTrab();
    }

    public static String getPiso(){
         return t.getPisoTrab();
    }

    public static String getMano(){
         return t.getManoTrab();
    }

    public static String getTelPersonal(){
         return t.getTlfPersonal();
    }

    public static String getTelMovil(){
         return t.getMovilEmp();
    }
        
    public static String getSalario(){
         return t.getSalario();
    }
    
    public static Date getFechaNac(){
         return t.getFechaNac();
    }
       
    public static boolean getTipo(){
         if (t instanceof Administracion)
            return true;
    return false;
    }
    
    public static boolean buscarDni(String dni) throws Exception{
         t = new Trabajador();
         TrabajadorBD.getTrabajador(t, dni);
         if (t == null)
             return false;
         return true;
     }

    public static void finalizar(){
        System.exit(0);
    }   

}

