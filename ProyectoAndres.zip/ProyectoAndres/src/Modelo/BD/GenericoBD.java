package Modelo.BD;

/**
 *
 * @author andrés
 */

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class GenericoBD {
    
    private static Connection conexion;
        
    public static Connection abrirBD(){
        try
        {
            DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
            conexion = DriverManager.getConnection("jdbc:oracle:thin:@SrvOracle:1521:orcl","montero","montero");
            return conexion;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            return null;
        }
    }
    public static boolean cerrarBD(Connection conexion){
        try
        {
          conexion.close();
          return true;
        }
        catch(Exception e){
            return false;
        }
    }
    
     public static Connection getCon(){
         return conexion;
     }
}

