/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.BD;

/**
 *
 * @author andrés
 */

import Modelo.UML.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.oracore.OracleType;
import proyectoandres.Main;

public class TrabajadorBD {
    
    public static ArrayList getTrabajadoresIdCentro(Connection conexion, String idCentro) throws Exception{
        ArrayList<String> trabajadores = new ArrayList();
        try{
            GenericoBD.abrirBD();
            CallableStatement cs = GenericoBD.getCon().prepareCall("{call proceduresTrab.get_trabajadores_centro(?,?)}");
            cs.setString(1, idCentro);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            ResultSet rs = (ResultSet) cs.getObject(2);
        while(rs.next()){
            trabajadores.add(rs.getString("DNI"));
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problemas al realizar query: "+e);
        }
        return trabajadores;
    }
    
    public static ArrayList getTrabajador(Trabajador t, String dni) throws Exception{
        ArrayList <String> ArrayTrabajador = new ArrayList();
        try{
        GenericoBD.abrirBD();
        CallableStatement cs = GenericoBD.getCon().prepareCall("{call proceduresTrab.get_trabajador(?,?)}");
        cs.setString(1, dni);
        cs.registerOutParameter(2, OracleTypes.CURSOR);
        cs.execute();
        ResultSet rs = (ResultSet) cs.getObject(2);
        while(rs.next()){
            if(rs.getString("Tipo").compareToIgnoreCase("Logistica") == 0) t = new Logistica();
            else t = new Administracion();
            
            t.setDNI(rs.getString("dni"));
            t.setNombre(rs.getString("nombre"));
            t.setApe1(rs.getString("apellido1"));
            t.setApe2(rs.getString("apellido2"));
            t.setCalleTrab(rs.getString("calle"));
            t.setPortalTrab(rs.getString("portal"));
            t.setPisoTrab(rs.getString("piso"));
            t.setManoTrab(rs.getString("mano"));
            t.setMovilEmp(rs.getString("telmovil"));
            t.setTlfPersonal(rs.getString("telpersonal"));
            t.setSalario(rs.getString("salario"));
            t.setFechaNac(new java.util.Date(rs.getDate("fechaNac").getTime()));
            
        }}
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problemas al realizar query: "+e);
        }
        return ArrayTrabajador;
    }
    
    public static void alta(Connection conexion, Trabajador t, String tipo) throws Exception{
            try{String plantilla = "INSERT INTO trabajador (idTipo, idTrabajador, DNI, nombre, ape1, ape2, fechaNac, salario, movilEmp, tlfPersonal, calle, portal, piso, mano) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement sentenciaCon = conexion.prepareStatement(plantilla);
            if(tipo.compareToIgnoreCase("Admin")==0)
                sentenciaCon.setInt(1,1);
            else sentenciaCon.setInt(1,2);
            
            sentenciaCon.setString(2,t.getIdTrabajador());
            sentenciaCon.setString(3,t.getDNI());
            sentenciaCon.setString(4,t.getNombre());
            sentenciaCon.setString(5,t.getApe1());
            sentenciaCon.setString(6,t.getApe2());
            sentenciaCon.setDate(7,new java.sql.Date(t.getFechaNac().getTime()));            
            sentenciaCon.setString(8,t.getSalario());
            sentenciaCon.setString(9,t.getMovilEmp());
            sentenciaCon.setString(10,t.getTlfPersonal());
            sentenciaCon.setString(11,t.getCalleTrab());
            sentenciaCon.setString(12,t.getPortalTrab());
            sentenciaCon.setString(13,t.getPisoTrab());
            sentenciaCon.setString(14,t.getManoTrab());
            sentenciaCon.executeUpdate();}
            catch(Exception e){JOptionPane.showMessageDialog(null,"Problemas" + e);}
            conexion.commit();
    }
	
	public static void modificacion (Connection conexion, Trabajador t, String tipo) throws Exception{       
            try{String plantilla = "update trabajador set idTrabajador = ?, DNI = ?, nombre = ?, ape1 = ?, ape2 = ?, fechaNac = ?, salario = ?, movilEmp = ?, tlfPersonal = ?, calle = ?, portal = ?, piso = ?, mano = ? where idtrabajador= ? ";
            PreparedStatement ps = conexion.prepareStatement(plantilla);
            ps.setString(1,t.getIdTrabajador());
            ps.setString(2,t.getDNI());
            ps.setString(3,t.getNombre());
            ps.setString(4,t.getApe1());
            ps.setString(5,t.getApe2());
            ps.setDate(7,new java.sql.Date(t.getFechaNac().getTime()));            
            ps.setString(7,t.getSalario());
            ps.setString(8,t.getMovilEmp());
            ps.setString(9,t.getTlfPersonal());
            ps.setString(10,t.getCalleTrab());
            ps.setString(11,t.getPortalTrab());
            ps.setString(12,t.getPisoTrab());
            ps.setString(13,t.getManoTrab());
            ps.setString(14,t.getIdTrabajador());
            ps.executeUpdate();
            } 
            catch(Exception e){JOptionPane.showMessageDialog(null,"Problemas" + e);}
            conexion.commit();
	}
	
	public static void eliminar(Connection conexion, Trabajador t) throws Exception {
            try{String plantilla = "delete from trabajador where idTrabajador = ?";
            PreparedStatement sentenciaCon = conexion.prepareStatement(plantilla);
            sentenciaCon.setString(1,t.getIdTrabajador());
            sentenciaCon.executeUpdate();
            }
            catch(Exception e){JOptionPane.showMessageDialog(null,"Problemas" + e);}
            conexion.commit();
	}

}
