/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.BD;

/**
 *
 * @author andrés
 */

import Modelo.UML.Centro;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleTypes;

public class CentroBD {
        
    public static ArrayList getCentros(Connection conexion, String idCentro, Centro c){
        ArrayList<String> tCentros = new ArrayList();
        try{
            GenericoBD.abrirBD();
            CallableStatement cs = GenericoBD.getCon().prepareCall("{call PAC_CENTRO.visualizar_datos_centro(?,?)}");
            cs.setString(1, idCentro);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            ResultSet rs = (ResultSet) cs.getObject(2);
                while(rs.next()){
                    c = new Centro();
                    c.setIdCentro(rs.getString("IdCentro"));
                    c.setNombreCen(rs.getString("Nombre"));
                    c.setTelefonoCen(rs.getString("Telefono"));
                    c.setCalleCen(rs.getString("Numero"));
                    c.setCpCen(rs.getString("CP"));
                    c.setCiudadCen(rs.getString("Ciudad"));
                    c.setProvinciaCen(rs.getString("Provincia"));                
                }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Problemas al realizar query: "+e);
        }
        if(!GenericoBD.cerrarBD(conexion)){
            JOptionPane.showMessageDialog(null,"Problemas al cerrar");
        }
        return tCentros;
    }
    
    public static void eliminarCentro(String id1, String id2) throws SQLException{
    GenericoBD.abrirBD();
    CallableStatement cs = GenericoBD.getCon().prepareCall("{call PAC_CENTRO.borrar_centro(?,?)}");
    cs.setString(1, id1);
    cs.setString(2, id2);
    cs.execute();
}
}
