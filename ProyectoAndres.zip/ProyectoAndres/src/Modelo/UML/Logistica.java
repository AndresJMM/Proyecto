/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.UML;

import java.util.Date;

/**
 *
 * @author andrés
 */
public class Logistica  extends Trabajador{
    public Logistica(String idTrabajador, String DNI, String nombre, String ape1, String ape2, String movilEmp, String calleTrab, String portalTrab, String pisoTrab, String manoTrab, Date fechaNac){
        super(idTrabajador, DNI, nombre, ape1, ape2, movilEmp, calleTrab, portalTrab, pisoTrab, manoTrab, fechaNac);
    }

    public Logistica() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
